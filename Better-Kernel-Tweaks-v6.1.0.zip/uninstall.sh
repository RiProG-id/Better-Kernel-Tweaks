#!/bin/sh
rm /storage/emulated/0/Android/BKT.log
